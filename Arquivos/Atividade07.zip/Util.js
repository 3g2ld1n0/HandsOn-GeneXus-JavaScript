function OpenPopUP(url, width, height) {
    window.open(url, 'MinhaJanela', 'width=' + width.toString() + ',height=' + height.toString());
}
function Calcular(valor1, valor2) {
    var resultado = 0;
    resultado = valor1 * valor2;
    $('#vRESULTADO').val(resultado);
    console.log('resultado', resultado);
    return resultado;
}
